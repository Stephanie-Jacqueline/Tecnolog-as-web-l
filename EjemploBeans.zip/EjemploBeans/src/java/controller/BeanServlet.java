/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import beans.PruebaBean;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Stephanie
 */
public class BeanServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Servlet BeanServlet</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Ejemplo con Servlet</h1>");
        PruebaBean bean = new PruebaBean();
        bean.setNombre(request.getParameter("nombre"));
        bean.setEdad(Integer.parseInt(request.getParameter("edad")));
        out.println("<h1>Nombre:"+bean.getNombre()+"</h1>");
        out.println("<h1>Edad:"+bean.getEdad()+"</h1>");
        out.println("</body>");
        out.println("</html>");

    }

  

}
